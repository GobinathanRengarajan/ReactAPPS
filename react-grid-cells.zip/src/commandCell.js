import React from 'react';
import ReactDOM from 'react-dom';
import { GridCell } from '@progress/kendo-react-grid';

export default function MyCommandCell(enterEdit, save, cancel, remove) {
  return class CustomCell extends GridCell {
    render() {
      return !this.props.dataItem.inEdit ?
        (
          <td>
            <button
              className="k-primary k-button k-grid-edit-command"
              onClick={() => enterEdit(this.props.dataItem)}
            > Edit
            </button>
            <button
              className="k-button k-grid-remove-command"
              onClick={() => confirm('Confirm deleting: ' + this.props.dataItem.ProductName) &&
                remove(this.props.dataItem)}
            > Remove
            </button>
          </td>
        ) : (
          <td>
            <button
              className="k-button k-grid-save-command"
              onClick={() => save(this.props.dataItem)}
            > {this.props.dataItem.ProductID ? 'Update' : 'Add'}
            </button>
            <button
              className="k-button k-grid-cancel-command"
              onClick={() => cancel(this.props.dataItem)}
            >{this.props.dataItem.ProductID ? 'Cancel' : 'Discard'}
            </button>
          </td>
        );
    }
  }
}