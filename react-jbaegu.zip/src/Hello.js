import React from 'react';

export default ({ name }) => <h1>Hello {name}!</h1>;
